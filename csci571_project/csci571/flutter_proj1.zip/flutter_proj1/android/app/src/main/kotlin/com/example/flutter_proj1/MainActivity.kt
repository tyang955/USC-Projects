package com.example.flutter_proj1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
